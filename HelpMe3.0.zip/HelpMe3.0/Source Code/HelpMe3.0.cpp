#include <windows.h>
#include <mmsystem.h>
#include <string>
#include <vector>
#include <thread>
#include <atomic>
#include <cmath>

#pragma comment(lib, "winmm.lib")

std::atomic<int> currentPayload(0);
std::atomic<bool> running(true);
const int PAYLOAD_DURATION = 20000; 

const std::vector<std::wstring> messages = {
    L"Is that a cut on my skin?", L"Am i alive yet", L"The fog is coming",
    L"Where am i?", L"Is that someone watching me?", L"Im not safe here",
    L"Who are you?", L"Your not safe here either"
};

unsigned char CalculateBytebeat(int p, unsigned int t) {
    if (t == 0) t = 1; 
    switch(p) {
        case 0: return ((t|t%255|t%257)+(t&t>>8)+(t*(42&t>>10))+((t%((t>>8|t>>16)+1))^t));
        case 1: return (t*(t>>(t>>13&t)));
        case 2: return ((t&((t>>18)+((t>>11)&t)))*t+(((t>>8&t)-(t>>3&t>>8|t>>16))&128));
        case 3: return (((t>>12&t>>8)>>(t>>20&t>>12))*t);
        case 4: return 10*(t&5*t|t>>6|(t&32768?-6*t/7:(t&65536?-9*t&100:-9*(t&100))/11));
        case 5: { unsigned int mask = (t & t >> 12); return t / (mask == 0 ? 1 : mask); }
        case 6: { unsigned int shift = t % ((t >> 12) == 0 ? 1 : (t >> 12)); return t >> shift | (t & t / 2 & t / 4) * t / 4000; }
        case 7: return (unsigned char)((int)(sin(t / (float)((t >> 10) == 0 ? 1 : (t >> 10))) * 128 + 128) ^ (int)(sqrt(t * 5)) ^ ((int)(pow(t * 3.14, 0.33) * (t & 0xFF)) >> 4) ^ (rand() % 256 > 200 ? 0xFF : 0));
        case 8: { int kick = sin(15 * sqrt(t % 4000)) * 128 + 128; int lead = sin(t * (3.14 / 8.0) * pow(((t >> 13 & 3) + 1), 0.33)) * 64; int hats = (rand() % 2000 < 100 ? 255 : 0); return (unsigned char)(kick * 0.7 + lead * 0.4 + hats * 0.2); }
        case 9: return 10*(t>>7|3*t|t>>(t>>15))+(t>>8&5);
        case 10: return (t>>(t>>12)%4)+t*(1+(1+(t>>16)%6)*(t>>10)*(t>>11)%8)^t>>13^t>>6;
        case 11: return 9*t&t>>4|5*t&t>>7|(3*t&t>>10)-1;
        case 12: return t*(0x21CA52CA>>(t>>9&30)&14)+t*(0xCACACACA>>(t>>9&30)&14)&t>>4;
        case 13: return (t^t>>12)*t>>8;
        case 14: return t^t/2^t*t/4000;
        case 15: return t*(-t>>(t>>13)%8+2&(t>>12)%256)/4+((t%65536 == 0) ? 0 : (1048576/(t%65536)&128));
        case 16: return t*t>>((t/350 == 0) ? 1 : (t/350));
        case 17: return t*(t&16384?7:5)*(1+(3&t>>10))>>(3&t>>8)|t>>2;
        case 18: return 2*(t>>5&t)-(t>>5)+t*(t>>14&14);
        case 19: return t*(t>>9&10|t>>11&24^t>>10&15&t>>15);
        default: return 0;
    }
}

int GetHz(int p) {
    int rates[] = {16000, 8000, 8000, 22050, 8000, 22050, 44100, 48000, 11025, 8000, 8000, 8000, 8000, 22050, 32000, 44100, 32000, 8000, 8000, 8000};
    return (p >= 0 && p < 20) ? rates[p] : 8000;
}

void AudioThread() {
    HWAVEOUT hWaveOut = NULL;
    WAVEHDR header[3];
    char buffers[3][8000];
    unsigned int t = 0;
    int lastPayload = -1;
    while (running) {
        int p = currentPayload.load();
        if (p != lastPayload) {
            if (hWaveOut) { waveOutReset(hWaveOut); waveOutClose(hWaveOut); }
            int hz = GetHz(p);
            WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, (DWORD)hz, (DWORD)hz, 1, 8, 0 };
            waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
            for (int i = 0; i < 3; i++) {
                header[i] = { buffers[i], 8000, 0, 0, 0, 0, NULL, 0 };
                waveOutPrepareHeader(hWaveOut, &header[i], sizeof(WAVEHDR));
                for (int j = 0; j < 8000; j++) buffers[i][j] = CalculateBytebeat(p, t++);
                waveOutWrite(hWaveOut, &header[i], sizeof(WAVEHDR));
            }
            lastPayload = p;
        }
        for (int i = 0; i < 3; i++) {
            if (header[i].dwFlags & WHDR_DONE) {
                for (int j = 0; j < 8000; j++) buffers[i][j] = CalculateBytebeat(p, t++);
                waveOutWrite(hWaveOut, &header[i], sizeof(WAVEHDR));
            }
        }
        Sleep(2);
    }
}

void RunGDI() {
    int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
    while (running) {
        HDC hdc = GetDC(NULL);
        if (!hdc) continue; 
        int p = currentPayload.load();
        switch(p) {
            case 0:
                BitBlt(hdc, rand()%10-5, rand()%10-5, sw, sh, hdc, 0, 0, SRCCOPY);
                PatBlt(hdc, rand()%sw, rand()%sh, rand()%200, rand()%200, DSTINVERT);
                break;
            case 1:
                StretchBlt(hdc, 0, 0, sw, sh, hdc, 10, 10, sw-20, sh-20, SRCPAINT);
                BitBlt(hdc, rand()%4, rand()%4, sw, sh, hdc, 0, 0, SRCAND);
                break;
            case 2:
                BitBlt(hdc, 0, 0, sw, sh, hdc, 0, 0, NOTSRCCOPY);
                for(int i=0; i<5; i++) PatBlt(hdc, rand()%sw, rand()%sh, 400, 400, PATINVERT);
                break;
            case 3:
                StretchBlt(hdc, rand()%20, rand()%20, sw, sh, hdc, 0, 0, sw, sh, MERGEPAINT);
                BitBlt(hdc, 2, 2, sw, sh, hdc, 0, 0, SRCERASE);
                break;
            case 4:
                {
                    HBRUSH hb = CreateSolidBrush(RGB(rand()%255, rand()%255, rand()%255));
                    HGDIOBJ old = SelectObject(hdc, hb);
                    PatBlt(hdc, 0, 0, sw, sh, PATINVERT);
                    SelectObject(hdc, old);
                    DeleteObject(hb);
                    StretchBlt(hdc, 10, 10, sw-20, sh-20, hdc, 0, 0, sw, sh, SRCCOPY);
                }
                break;
            case 5:
                BitBlt(hdc, rand()%5, rand()%5, sw, sh, hdc, 0, 0, SRCINVERT);
                BitBlt(hdc, 0, 0, sw, sh, hdc, 0, 0, 0x999999);
                break;
            case 6:
                BitBlt(hdc, 0, 0, sw, sh, hdc, 0, 0, DSTINVERT);
                StretchBlt(hdc, rand()%100, rand()%100, sw-200, sh-200, hdc, 0, 0, sw, sh, SRCPAINT);
                break;
            case 7:
                StretchBlt(hdc, 1, 1, sw-2, sh-2, hdc, 0, 0, sw, sh, SRCCOPY);
                BitBlt(hdc, 0, 0, sw, sh, hdc, 0, 0, NOTSRCERASE);
                break;
            case 8:
                BitBlt(hdc, rand()%20-10, rand()%20-10, sw, sh, hdc, 0, 0, SRCCOPY);
                PatBlt(hdc, 0, 0, sw, sh, DSTINVERT);
                break;
            case 9:
                StretchBlt(hdc, rand()%10-5, rand()%10-5, sw+10, sh+10, hdc, 0, 0, sw, sh, SRCPAINT);
                BitBlt(hdc, 0, 0, sw, sh, hdc, 0, 0, NOTSRCCOPY);
                break;
            case 10:
                BitBlt(hdc, 0, 10, sw, sh, hdc, 0, 0, SRCCOPY);
                BitBlt(hdc, 0, 0, sw, sh, hdc, 10, 0, SRCPAINT);
                break;
            case 11:
                PatBlt(hdc, 0, 0, sw, sh, WHITENESS);
                BitBlt(hdc, rand()%20, rand()%20, sw, sh, hdc, 0, 0, SRCAND);
                break;
            case 12:
                BitBlt(hdc, 5, 5, sw, sh, hdc, 0, 0, SRCINVERT);
                BitBlt(hdc, -5, -5, sw, sh, hdc, 0, 0, SRCCOPY);
                break;
            case 13:
                StretchBlt(hdc, 0, 0, sw, sh, hdc, sw/4, sh/4, sw/2, sh/2, SRCCOPY);
                BitBlt(hdc, rand()%50, rand()%50, sw, sh, hdc, 0, 0, SRCPAINT);
                break;
            case 14:
                BitBlt(hdc, 0, 0, sw, sh, hdc, 0, 0, NOTSRCCOPY);
                BitBlt(hdc, 20, 0, sw, sh, hdc, 0, 0, SRCAND);
                break;
            case 15:
                StretchBlt(hdc, -10, -10, sw+20, sh+20, hdc, 0, 0, sw, sh, SRCCOPY);
                BitBlt(hdc, rand()%10, 0, sw, sh, hdc, 0, 0, SRCPAINT);
                break;
            case 16:
                BitBlt(hdc, 0, 0, sw, sh, hdc, 0, 0, 0x123456);
                BitBlt(hdc, rand()%2, rand()%2, sw, sh, hdc, 0, 0, SRCCOPY);
                break;
            case 17:
                BitBlt(hdc, -10, -10, sw, sh, hdc, 0, 0, SRCCOPY);
                BitBlt(hdc, 0, 0, sw, sh, hdc, 0, 0, NOTSRCERASE);
                break;
            case 18:
                {
                    HBRUSH b = CreateHatchBrush(rand()%6, RGB(rand()%255, rand()%255, rand()%255));
                    HGDIOBJ old = SelectObject(hdc, b);
                    PatBlt(hdc, 0, 0, sw, sh, PATINVERT);
                    SelectObject(hdc, old);
                    DeleteObject(b);
                    StretchBlt(hdc, 5, 5, sw-10, sh-10, hdc, 0, 0, sw, sh, SRCCOPY);
                }
                break;
            case 19:
                BitBlt(hdc, 0, 0, sw, sh, hdc, 0, 0, NOTSRCCOPY);
                StretchBlt(hdc, 5, 5, sw-10, sh-10, hdc, 0, 0, sw, sh, SRCCOPY);
                break;
            default:
                BitBlt(hdc, rand()%2-1, rand()%2-1, sw, sh, hdc, 0, 0, SRCINVERT);
                break;
        }
        ReleaseDC(NULL, hdc); 
        Sleep(10);
    }
}

int WINAPI WinMain(HINSTANCE h, HINSTANCE hp, LPSTR c, int s) {
    std::thread audio(AudioThread);
    std::thread timer([]() {
        for(int i=0; i<20; i++) {
            Sleep(PAYLOAD_DURATION);
            currentPayload++;
        }
        running = false;
    });
    RunGDI();
    if(audio.joinable()) audio.join();
    if(timer.joinable()) timer.join();
    return 0;
}